package com.java_basics;
import java.util.ArrayList;
import java.util.List;
public class colors_ArrayList {
    public static void main(String[] args) {
        //creating a new array list
        List<String>colors = new ArrayList<>();
        //add colors to the array list
        colors.add("Red");
        colors.add("Green");
        colors.add("Black");
        colors.add("Blue");
        colors.add("Smoke White");
        //printing the collection
        System.out.println(colors);
    }
}
